import pandas as pd
import matplotlib.pyplot as plt
import pandas as pd
import pickle

dft = pd.read_csv('/home/amir/Downloads/lven/df9.csv')
dft.info()


X = dft.iloc[:, [2,4]]
y = dft.iloc[:,1]

from sklearn.linear_model import LinearRegression
regressor = LinearRegression()

regressor.fit(X,y)

pickle.dump(regressor, open('model1.pkl','wb'))
model = pickle.load(open('model1.pkl','rb'))
print(model.predict([[1703,0.60]]))
